<form method="post" action="demoPHP_post.php">
  <p> Nama : <br />
    <input name="nama" type="text" id="nama_x" size="20" placeholder="Masukkan nama"/>
  </p>
  <p>NIM : <br />
    <input name="nim" type="text" id="nim_x" size="20" placeholder="Masukkan NIM"/>
  </p>
  <p>
    <input type="submit" name="button" id="button" value="Kirim" />
  </p>
</form>