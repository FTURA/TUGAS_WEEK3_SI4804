<?php
  echo "Ini data yang ditampilkan menggunakan metode GET <br>";
  echo $_GET['nama']."<br>";
  echo $_GET['nim'];
?>