<?php
  echo "Ini data yang ditampilkan menggunakan metode POST <br>";
  echo $_POST['nama']."<br>";
  echo $_POST['nim'];
?>